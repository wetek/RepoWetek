import xbmc
import xbmcgui
import xbmcaddon

__author__ = 'LuFi'
__scriptid__ = 'script.config.vdr'
__vdrscriptid__ = 'service.multimedia.vdr-addon'
__addon__ = xbmcaddon.Addon(id=__scriptid__)
__cwd__ = __addon__.getAddonInfo('path')

try:
    __vrdaddon__ = xbmcaddon.Addon(id=__vdrscriptid__)
except Exception, e:
    xbmc.executebuiltin('Notification(VDR Configuration, VDR Plugin not found, 5000, "")')
    quit()

def _(code):
    if isinstance(code, int):
        return __addon__.getLocalizedString(code)
    else:
        return code

if __name__ == '__main__':
    lObjSelectDialog = xbmcgui.Dialog()
    lIntResult = lObjSelectDialog.select(_(32300), [_(32301), _(32302)])    
    if lIntResult == 0:
        import scan
    else:
        import diseqc
    