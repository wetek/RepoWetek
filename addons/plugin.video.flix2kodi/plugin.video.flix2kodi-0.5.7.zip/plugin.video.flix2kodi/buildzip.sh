zip -r plugin.video.flix2kodi.zip plugin.video.flix2kodi -x plugin.video.flix2kodi/.git\* plugin.video.flix2kodi/copy2repo.sh plugin.video.f$

