#!/bin/sh

# copy from https://github.com/andrewleech/plugin.video.netflixbmc/blob/master/browser.sh

# Managed to resolve the issues with, but will leave this here anyway, as its a good fallback
CHROME_STARTED=`ps -ef | grep google-chrome | grep -v "grep" | wc -l`
if [ $CHROME_STARTED -gt 0 ]; then
        exit 1;
fi

# lets find out if xdotool actually exist before we try to call them.
command -v xdotool >/dev/null 2>&1
XDOTOOL=$?

url=$1

# notice the ampersand to send google chrome into back ground so that the script continues and we execute the xdotool below
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --koisk --start-fullscreen "$url" &
CHROME_PID=$!

if [ $XDOTOOL -eq 0 ]; then
        # no point sleeping if xdotool is not installed.
        sleep 5
        xdotool mousemove 9999 9999 click 1
else
        echo "xdotool is not installed, can't remove cursor"
fi
# wait for google-chrome to be killed 
wait $CHROME_PID

