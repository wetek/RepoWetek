# -*- coding: utf-8 -*-
#------------------------------------------------------------
# smytvshow
# Plugin wrapper to xbmc
# http://smystero.dlinkddns.org/smytvwhow/
#------------------------------------------------------------

import xbmcplugin

import config
import logger


def set_content_to_tv_shows():
    logger.debug("tvshows")
    xbmcplugin.setContent(config.get_handle(), "tvshows")
    return


def set_content_to_movies():
    logger.debug("movies")
    xbmcplugin.setContent(config.get_handle(), "movies")
    return


def set_content_to_episodes():
    logger.debug("episodes")
    xbmcplugin.setContent(config.get_handle(), "episodes")
    return


def add_directory_item(list_item, url, folder, total_items=0):
    xbmcplugin.addDirectoryItem(config.get_handle(), url=url, listitem=list_item, isFolder=folder, totalItems=total_items)


def end_of_directory(succeeded=True, update=False):
    xbmcplugin.endOfDirectory(config.get_handle(), succeeded, update)
