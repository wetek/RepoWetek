# -*- coding: utf-8 -*-
# ------------------------------------------------------------
# smytvshow
# Message wrapper to xbmc
# http://smystero.dlinkddns.org/smytvwhow/
# ------------------------------------------------------------

import xbmc
import config

def notification(message, header=config.get_name(), time=1, icon=config.get_add_on().getAddonInfo('icon')):
    xbmc.executebuiltin("XBMC.Notification(%s,%s,%i,%s)" % (header, message, time, icon))

