import sys
import requests
import hashlib
import xbmcgui
import xbmcplugin
import xbmcaddon
from time import gmtime, strftime

def show_error(message):
    dialog = xbmcgui.Dialog()
    ok = dialog.ok('WeCloud Antenna', message)

LOGIN_URL = "http://wetek.zebraott.com/api/login/%s/%s/%s/android"
PRIV_CHANNELS_URL = 'https://wetek.com/api/user_channels?auth=%s&email=%s&p=%s'

addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()

if (not addon.getSetting('wecloud.firstrun')):
    addon.setSetting('wecloud.firstrun', '1')
    addon.openSettings()

deviceid = addon.getSetting('wecloud.deviceid')
username = addon.getSetting('wecloud.username')
password = hashlib.md5(addon.getSetting('wecloud.password')).hexdigest()
passpriv = hashlib.sha1('DYhG93b0qysdhfkSD33VddseniR2G340FgaC9mi' + addon.getSetting('wecloud.password')).hexdigest()

xbmcplugin.setContent(addon_handle, 'videos')

try:
    login_data = requests.get(LOGIN_URL % (username, password, deviceid)).json()
    chlist_url = login_data['Client']['Api']['list_channels']
except:
    show_error('Giri\xc5\x9f Yap\xc4\xb1lamad\xc4\xb1')
    addon.openSettings()
    exit(0)

try:
    # PRIVATE CHANNELS
    try:
        year, month, day, hour, minute = strftime("%Y %m %d %H %M", gmtime()).split()
        timehash = hashlib.md5(str((int(year) + int(month) + int(day)) * int(hour) * int(minute))).hexdigest()
        channel_data = requests.get(PRIV_CHANNELS_URL % (timehash, username, passpriv)).json()

        for ch in channel_data['data']:
            title = ch['Content']['title']
            stream_url = ch['Content']['url']
            logo = ch['Content']['logo']
            li = xbmcgui.ListItem('[PRIV] ' + title, iconImage=logo)
            li.setMimeType('video/mpeg')
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li)
    except:
        show_error('\xc3\x96zel Kanal Listesi Al\xc4\xb1namad\xc4\xb1')
        pass

    # PRIVATE CHANNELS
    channel_data = requests.get(chlist_url).json()

    for ch in channel_data['channels']:
        title = ch['channel']['title']
        stream_url = ch['channel']['stream_url']
        logo = ch['channel']['logo']
        li = xbmcgui.ListItem(title, iconImage=logo)
        li.setMimeType('video/mpeg')
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li)

    xbmcplugin.endOfDirectory(addon_handle)
except:
    show_error('Kanal Listesi Al\xc4\xb1namad\xc4\xb1')
    exit(0)
