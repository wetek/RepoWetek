
import sys
import urllib,urllib2,cookielib
import re,xbmcplugin,xbmcgui,xbmcaddon,xbmc
import json


xbmcPlayer = xbmc.Player()
playList = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

HEADERS = {
	'User-Agent': 	 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36',
	'Accept': 		 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Cache-Control': 'no-transform'
}

ben = 'http://xorixori-001-site1.mywindowshosting.com/XorService.svc/xorvod/ana/xorion?url=xor'


def HadiBakalim():
        xorion(ben)
def xorion(url):
    f = urllib2.urlopen(url)
    js = json.load(f)
   
   
    for rs in js['Linklerim']:
            baslik=rs['Baslik'].encode('utf-8')
            resim=rs['Resim'].encode('utf-8')
            bak=rs['StreamUrl']
            linkim = rs['PlayList']
            #siraNo=str(rs['idNo'])
            koruma=rs['Koruma']
           

            if not bak: 
                url= str(linkim) 
                if  not koruma=="True":
                    addDir('[COLOR orange][B]'+ baslik +'[/B][/COLOR]',url,2,resim)
                else:
                    addDir('[COLOR red][B]' + '(+18) > '+ baslik + '[/B][/COLOR]',url,2,resim)
            else:
                url=str(bak)
                #print 'bbbstream :' + url
                addDir('[COLOR white][B]' + baslik + '[/B][/COLOR]',url,3,resim)
def oynat(url,baslik):       
        playList.clear()
        url = str(url).encode('utf-8', 'ignore')
        
        
        if "vk.com" in url:
                url= VKoynat(url)
        elif "mail.ru" in url:
                url= MailruOynat(url)
        elif "youtube" in url:
                url= YoutubeOynat(url)
        elif "dailymotion" in url:
                url= DailyOynat(url)		
        elif "videoraj" in url:
                url= VideoRaj(url)	
        
        elif "cloudy" in url:
                url= VideoRaj(url)
				
        elif 'ok.ru/videoembed' in url or 'odnoklassniki.ru/video' in url:
               
                url=OkRu(url)		
				
        elif "novamov" in url:
                url= DivxCloud(url)
        elif "divxstage" in url:
                url= DivxCloud(url)
        elif "embed.movshare" in url:
                url= MovNow(url)
        elif "embed.nowvideo" in url:
                url= MovNow(url)
       
        elif "docs.google.com" in url:			
				url= google(url)
				
        elif "vid.ag" in url:			
                url= VidAg(url)		
				
        else:
                url=url
        if url:
                addLink(baslik,url,'')
                
                listitem = xbmcgui.ListItem(baslik, iconImage="DefaultFolder.png", thumbnailImage='')
                listitem.setInfo('video', {'name': baslik } )
                playList.add(url,listitem=listitem)
                xbmcPlayer.play(playList)
        else:
                showMessage("[COLOR blue][B]Xor[/B][/COLOR]","[COLOR blue][B]Link bulunamadi ya da acilamiyor[/B][/COLOR]")

def MailruOynat(url):
                    
                    result = re.findall('(mail/.*?).html', url)
                    if result:
                        url = 'http://api.video.mail.ru/videos/' + result[0] + '.json'
                    req = urllib2.Request(url)
                    link = urllib2.urlopen(req)
                    page = link.read()
                    vkey = []
                    for cookie in re.finditer('(video_key=[^\\;]+)', link.headers.get('Set-Cookie'), re.IGNORECASE | re.DOTALL):
                        vkey.append(cookie.group(1))

                    headers = {'Cookie': vkey[-1]}
                    videos = re.findall('p","url":"(.*?)"', page)
                    if not videos:
                        videos = re.findall('(http://api.video.mail.ru/file.*?)[\\\'|"],"', page)
                    qualitylist = re.findall('"(sd|md|hd|full_hd)":"', page)
                    if not qualitylist:
                        qualitylist = re.findall('key":"(.*?)","url"', page)
                        dialog = xbmcgui.Dialog()
                        ret = dialog.select('kalite secin...',qualitylist)
                    if videos:
                        videolist = [ v + '|Cookie:' + vkey[0] for v in videos ]
                       
                        dialog = xbmcgui.Dialog()
                        ret = dialog.select('kalite secin...',qualitylist)
                        return videolist[ret]
                    else:
                        return videolist[ret]
	
	
	
	
	
	         
                   

def VKoynat(url):
        url = url.replace('https', 'http')
        page = get_url(url)
        vids = re.findall('"url.*?":"(.*?)"', page)
        quals = re.findall('"url(.*?)":"', page)
        videolist = [ reg.replace('\\','').replace('"','') for reg in vids]
        qualitylist = [ qual + 'p' for qual in quals ]
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite secin...',qualitylist)
        return videolist[ret]

def YoutubeOynat(url):
        
        code=re.match('^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=)([^#\&\?]*).*', url)
        url='plugin://plugin.video.youtube/?action=play_video&videoid=' + str(code.group(2))

        return url

		
		
def DailyOynat(url):
        qualitylist =[]
        videolist=[]
        url = url.replace('dailymotion.com/video/', 'dailymotion.com/embed/video/')
        page = get_url(url)
        array = re.findall('stream_h264_(?:hd1080_|ld_|hq_|hd_|)url":"(.*?H264-(.*?)\\\\/.*?)"', page)
        if array:
                for v, q in array:
                        url = v.replace('\\', '')
                        videolist.append(url)
                        qualitylist.append(q+"p")
        array1 = re.findall('"(\\d+)":\\[{"type":"video\\\\\\/mp4","url":"([^"]+)"}]', page)
        if array1:
                for v, q in array1:
                        url = q.replace('\\', '')
                        videolist.append(url)
                        qualitylist.append(v+"p")
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite secin...',qualitylist)
        return videolist[ret]		
		

def google(url):

        if 'plus.google.com' in url:
                if "oid" in url:
                        oid = re.findall('oid=([0-9]+)',url)[0]
                        pid = re.findall('pid=([0-9]+)',url)[0]
                else:
                        ids = url.split("/")
                        oid = ids[4]
                        pid = ids[7]
                url = "https://picasaweb.google.com/data/feed/tiny/user/"+oid+"/photoid/"+pid+"?alt=jsonm";
        request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        response = urllib2.urlopen(request)
        html = response.read().decode('unicode-escape')
        
        if 'picasaweb.google.com' in url:
                links_part = re.findall('"https://redirector(.*?)"', html)
                pre_link = 'https://redirector'


        if 'docs.google.com' in url:
                links_parts = re.findall('"fmt_stream_map","(.*?)"', html)[0]
                links_part = re.findall('\\|(.*?),', links_parts)
                pre_link =''
        videolist = []
        qualitylist = []
        for link_part in links_part:                       
                if link_part.encode('utf_8').find("itag=18") > -1:
                        videolist.append(pre_link + link_part.encode('utf_8'))
                        qualitylist.append("360p")
                if link_part.encode('utf_8').find("itag=22") > -1:
                        videolist.append(pre_link + link_part.encode('utf_8'))
                        qualitylist.append("720p")
                if link_part.encode('utf_8').find("itag=37") > -1:
                        videolist.append(pre_link + link_part.encode('utf_8'))
                        qualitylist.append("1080p")
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite secin...',qualitylist)
        return videolist[ret]

def MovNow(url):
        request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        secondpage = urllib2.urlopen(request).read()
        link = re.findall('flashvars\\.file="(.*?)";', secondpage)
        key = re.findall('var fkzd="(.*?)";', secondpage)
        if 'embed.movshare' in url:
                video = 'http://www.movshare.net/api/player.api.php?file=' + link[0] + '&key=' + key[0]
        else:
                video = 'http://www.nowvideo.sx/api/player.api.php?file=' + link[0] + '&key=' + key[0]
        request2 = urllib2.Request(video, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        thirdpage = urllib2.urlopen(request2).read()
        return re.findall('url=(.*?flv)', thirdpage)[0]

def DivxCloud(url):
        
        url = url.replace("http://embed.divxstage.eu/embed.php?v=","http://www.cloudtime.to/video/")
        url = url.replace("http://www.divxstage.eu/video/","http://www.cloudtime.to/video/")
        url = url.replace("http://www.divxstage.to/video/","http://www.cloudtime.to/video/")
        request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        page = urllib2.urlopen(request).read()
        link = re.findall('flashvars.file="(.*?)";', page)
        key = re.findall('flashvars.filekey="(.*?)";', page)
        if 'novamov' in url:
                video = 'http://www.novamov.com/api/player.api.php?file=' + link[0] + '&key=' + key[0]
        else :
                video = 'http://www.cloudtime.to/api/player.api.php?file=' + link[0] + '&key=' + key[0]
        request2 = urllib2.Request(video, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        page2 = urllib2.urlopen(request2).read()
        return urllib.unquote(re.findall('url=(.*?)&', page2)[0])		
		
		
def OkRu(url):
		qualitylist =[]
		videolist=[]
		id = re.findall('http://(?:odnoklassniki|ok).ru/videoembed/(\\d+)', url)[0]
		jsonUrl = 'http://ok.ru/dk?cmd=videoPlayerMetadata&mid=' + id
		jsonSource = json.loads(get_url(jsonUrl))
		
		
		for source in jsonSource['videos']:
                    name = '%s %s' % ('[ok.ru]',source['name'])
                    link = '%s|User-Agent=%s&Accept=%s&Referer=%s'
                    link = link % (source['url'], HEADERS['User-Agent'], HEADERS['Accept'], url)
					
                    item = {'name': name, 'url': link}
					
                    qualitylist.append(item['name'])
                    
                    videolist.append(item['url'])
          
		dialog=xbmcgui.Dialog()
		secim=dialog.select('Kalite Secin...',qualitylist)
		
		return videolist[secim]
		

		
def VideoRaj(url):
        
        url = url.replace ("http://www.videoraj.ch/v/","http://www.videoraj.ch/embed.php?id=")
        request = urllib2.Request(url, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        page = urllib2.urlopen(request).read()
        link = re.findall('file:"(.*?)",', page)
        key = re.findall('key: "(.*?)",', page)
        domain = re.findall('domain: "(.*?)",', page)
        if 'videoraj' in url:
                video = "http://www.videoraj.ch/api/player.api.php?file="+ link[0] + "&key="+key[0]
        else:
                video = 'http://www.cloudy.ec/api/player.api.php?user=undefined&codes=1&file=' + link[0] + '&pass=undefined&key=' + key[0]
        request2 = urllib2.Request(video, None, {'User-agent': 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3','Connection': 'Close'})
        page2 = urllib2.urlopen(request2).read()
        return urllib.unquote(re.findall('url=(.*?)&', page2)[0])		
		
def VidAg(url):
        page = get_url(url)
        vids = re.findall(',{file:"(.*?mp4)"', page)
        quals = re.findall('",label:"(.*?)"', page)
        videolist = [ reg.replace('\\','').replace('"','') for reg in vids]
        qualitylist = [ qual + '' for qual in quals ]
        dialog = xbmcgui.Dialog()
        ret = dialog.select('kalite secin...',qualitylist)
        return videolist[ret]


		
def get_url(url):
        req = urllib2.Request(url)
        req.add_header('Referer', url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36')
        #req.add_header('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8')
        #req.add_header('Cache-Control', 'no-transform')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        return link
def showMessage(heading='Xor', message = '', times = 3000, pics = ''):
		try: xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")' % (heading, message, times, pics))
		except Exception, e:
			xbmc.log( '[%s]: showMessage: exec failed [%s]' % ('', e), 1 )
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addDir(name,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]               
        return param
params=get_params()
url=None
name=None
mode=None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass

if mode==None or url==None or len(url)<1:
       
        HadiBakalim()
       
elif mode==2:
       
        xorion(url)
        
elif mode==3:
       
        oynat(url,name)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
